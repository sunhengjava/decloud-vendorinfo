package com.nari.iot.vendorinfo.common;

public class Constant {

    /**
     * 微服务调用方式
     * rest/feign
     */
    public static final boolean CALL_TYPE_IS_FEIGN = false;
    public static final String SMS_URL="http://22.56.217.142:9001/osp/ssda_sms/rest/sendzdymsg/sendzdy";

}
