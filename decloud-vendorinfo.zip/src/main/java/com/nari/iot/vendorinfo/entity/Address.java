package com.nari.iot.vendorinfo.entity;

/**
 * @program: decloud-vendorinfo
 * @description:
 * @author: sunheng
 * @create: 2023-01-10 17:11
 **/
public class Address {
    //1、参数设置，2、参数激活，3、参数召测。

    //    //1、参数配置参数召测接口
   public  static   String ADDR1= "http://25.212.172.50:9099/decloud-interaction/commandApi/commandParameterApi";

}
